Welcome to the world of ISY 

Contents:
./doc					- Contains all the Javadocs for all the library packages and examples
./example				- Contains a fully functional ISY client example for Insteon (with source)
./lib 					- Contains the ISY JSDK library (isy_inst.jar) for Insteon
./ISY-JSDK-Manual.pdf 			- ISY principles and JSDK information 
./myisy.bat				- Runs the exmaple in ./example
./Readme.txt				- This file


Quick Start:
Run the ./myisy.bat 

Development:
1. Include ./lib/isy_inst.jar as part of the classpath in your IDE
2. Import ./example/*.java files into your IDE
3. Review the source for all the ./example/*.java files

In case of questions:
Contact tech@universal-devices.com

Change History:
Version 2.5 (11/27/2007):
Added the following callback functions:
public void onDeviceSpecific(String arg1,XMLElement arg2) ;
public void onProgress(String arg1, XMLElement arg2);

Version 2.1:
1. Support for new services: RestoreDevicesFromNodes, RestoreDeviceFromNode, RestoreModem
2. Updates to existing services: 
	2a. AddNode now takes a flag for the operation(s) to be followed immediately after the node is added
	2b. CancelNodeDiscovery now takes a flag for the operation(s) to be performed after the node are linked
3. Ramprate is now handled in a more granular manner using values 0 to 31 (instead of percentage)

Thank you!