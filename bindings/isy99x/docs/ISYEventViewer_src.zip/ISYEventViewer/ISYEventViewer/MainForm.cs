﻿//
// Copyright (C) 2009 Robert Paauwe
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace ISYEventViewer {
	public partial class MainForm : Form {
		ISYEvents iev;
		private static bool running;

		public MainForm() {
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e) {
			iev = new ISYEvents();
			iev.SendMessage += new ISYEvents.EventMessageHandler(this.UpdateWithEvent);
			//ISYEvents.AddClient(this.UpdateWithEvent);
			running = false;

		}

		private void button1_Click(object sender, EventArgs e) {

			// Should this start a thread? Probably.
			if (!running) {
				iev.Start(this.textBox1.Text, this.textBox2.Text, this.textBox3.Text);
				running = true;
				this.button1.Text = "Stop";
			} else {
				iev.Stop();
				running = false;
				this.button1.Text = "Start";
			}
		}

		//
		// This is called by the thread that subscribed to the ISY's
		// events whenever a new event comes in. It simply updates
		// the listbox.
		private void UpdateWithEvent(object sender, ISYEventMessage msg) {
			UpdateListBox(msg);
		}

		internal delegate void UpdateListBoxCallback(ISYEventMessage message);

		private void UpdateListBox(ISYEventMessage message) {
			//int v_lines;
			try {
				if (EvntLB.InvokeRequired) {
					UpdateListBoxCallback d = new UpdateListBoxCallback(UpdateListBox);
					this.Invoke(d, new object[] { message });
					EvntLB.Items[EvntLB.Items.Count - 1].EnsureVisible();
					//v_lines = (int)(EvntLB.Height / EvntLB.ItemHeight);
					//EvntLB.TopIndex = EvntLB.Items.Count - v_lines + 1;
				} else {

					//EvntLB.Items.Add(message);
					EvntLB.Items.Add(new ListViewItem(new string[] {message.TimeStamp, message.Sequence,
						message.Control, message.Action, message.Node, message.EventInfo}));
					EvntLB.Items[EvntLB.Items.Count - 1].EnsureVisible();

					//v_lines = (int)(EvntLB.Height / EvntLB.ItemHeight);
					//EvntLB.TopIndex = EvntLB.Items.Count - v_lines + 1;
				}
			} catch {
			}
		}

		//
		//  Use this to copy any selected rows to the clipboard
		//
		private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e) {
			string cpystr = "";

			foreach (ColumnHeader ch in EvntLB.Columns) {
				cpystr += ch.Text + "\t";
			}
			cpystr += "\r\n";

			for (int i = 0; i < EvntLB.Items.Count; i++) {
				if (EvntLB.Items[i].Selected == true) {
					for (int j = 0; j < EvntLB.Columns.Count; j++) {
						cpystr += EvntLB.Items[i].SubItems[j].Text + "\t";
					}
					cpystr += "\r\n";
				}
			}

			Clipboard.SetDataObject(cpystr, true);
		}
	}
}
