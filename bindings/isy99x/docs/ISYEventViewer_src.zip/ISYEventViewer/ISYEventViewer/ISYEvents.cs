﻿//
// Copyright (C) 2009 Robert Paauwe
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Xml;

namespace ISYEventViewer {
	internal class node {
		public string Name;
		public string Address;
		public string Type;
		public string ElkID;
		public string Group;
		public string Flag;
	}

	//
	// TODO: Can this be expanded to do some of the parsing? For instance
	//       if the control comes in as "_1" then convert that to the name.
	//
	internal class ISYEventMessage {
		public string Control;
		public string Action;
		public string Node;
		public string EventInfo;
		public string TimeStamp;
		public string Sequence;

		internal ISYEventMessage() {
			Sequence = "";
			Control = "";
			Action = "";
			Node = "";
			EventInfo = "";
			TimeStamp = DateTime.Now.ToShortTimeString();
		}

		internal ISYEventMessage(string s, string c, string a, string n, string e) {
			Sequence = s;
			Control = c;
			Action = a;
			Node = n;
			EventInfo = e;
			TimeStamp = DateTime.Now.ToShortTimeString();
		}
	}

    internal class ISYEvents {
		static TcpClient sock;
		static StreamReader reader = null;
        static StreamWriter writer = null;
		static string s;
		static ArrayList isy_node = new ArrayList();
		private static Thread sub_thread;
		private string ip_address;
		private string username;
		private string password;
		private Boolean running;

		internal event EventMessageHandler SendMessage;
		internal delegate void EventMessageHandler(object sender, ISYEventMessage msg);


		internal ISYEvents() {
		}

		internal void Start(string ip, string u, string p) {
			ip_address = ip;
			username = u;
			password = p;
			running = true;
			sub_thread = new Thread(new ThreadStart(this.Connect));
			sub_thread.IsBackground = true;
			sub_thread.Start();
			//Connect();
		}

		internal void Stop() {
			running = false;
			sock.Close();
			sub_thread.Abort();
		}

        private void Connect() {
            System.Text.ASCIIEncoding encoding = new ASCIIEncoding();
            string auth =
                ("Basic " + Convert.ToBase64String(encoding.GetBytes(username + ":" + password)));

			// Loop at this level to retry connections
			while (running) {
				// Get Node info
				ErrorNotify("Get Nodes Config.");
				GetNodesConfig(ip_address, auth);

				// Set logging level to 1
				SetDebugging(ip_address, auth);

				// Subscribe to ISY events and display them as they come in
				ErrorNotify("Start Subscription.");
				doSubscribe(ip_address, auth);

				Thread.Sleep(50000); // maybe 5 seconds
			}
		}

		private void doSubscribe(string ip_address, string auth) {
            System.Text.ASCIIEncoding encoding = new ASCIIEncoding();
            bool headers = false;
            int content_length = 0;

			// At this point do we need to open a listening socket?
			sock = new TcpClient();
			if (ip_address.Contains(":")) {
				// Handle non default port numbers.
				string[] ip = ip_address.Split(':');
				sock.Connect(ip[0], int.Parse(ip[1]));
			} else {
				sock.Connect(ip_address, 80);  // 80 is the default port number
			}

			try {
				reader = new StreamReader(sock.GetStream());
			} catch {
				ErrorNotify("Failed to create a stream reader.");
				sock.Close();
				return;
			}

			string subreq = "<s:Envelope><s:Body>" + "<u:Subscribe";
			subreq += " xmlns:u=\'urn:udi-com:service:X_Insteon_Lighting_Service:1\'>";
			subreq += "<reportURL>REUSE_SOCKET</reportURL>";
			subreq += "<duration>infinite</duration>";
			subreq += "</u:Subscribe></s:Body></s:Envelope>\r\n";


			try {
				writer = new StreamWriter(sock.GetStream());
			} catch (Exception ex) {
				ErrorNotify("StreamWriter: " + ex.Message);
				sock.Close();
				return;
			}

			writer.WriteLine("POST /services HTTP/1.1");
			writer.WriteLine("ContentType: text/xml; charset=utf-8");
			writer.WriteLine("Authorization: " + auth);
			writer.WriteLine("Content-Length: " + subreq.Length.ToString());
			writer.WriteLine("SOAPAction: urn:udi-com:device:X_Insteon_Lighting_Service:1#Subscribe");
			writer.WriteLine();
			writer.Write(subreq);
			writer.Flush();

			sock.ReceiveTimeout = 120000;  // 60 seconds?

			while (true) {
				char[] buf;
				string xml_str;

				try {
					s = reader.ReadLine();
					//NotifyAll("read: " + s);
				} catch {
					ErrorNotify("Read failed, connection closed.");
					sock.Close();
					break;
				}

				if (s == null) {
					ErrorNotify("Read returned NULL, connection closed.");
					sock.Close();
					break;
				}

				if (s.Contains("CONTENT-LENGTH")) {
					content_length = int.Parse(s.Substring(15));
					headers = true;
				} else if (s == "") {
					if (headers == true) {
						// We read in the headers and have content length
						// so read the block of data.
						buf = new char[content_length + 2];

						reader.ReadBlock(buf, 0, content_length);
						content_length = 0;

						string str = new string(buf);

						if (str.StartsWith("<?xml")) {
							xml_str = str.Substring(21); // strip beginning

							// Parse and log event
							ParseEvent(xml_str);
						} else {
							ErrorNotify("Invalid XML from ISY: " + str);
						}
					}
					headers = false; // reset for next event
					//NotifyAll(-1, "Headers = false, look for next event");
				} else {
					// ignore line because it is a header.
				}
			}
        }


		//
		// Parse the XML event data from the ISY
		//
		private void ParseEvent(string xml) {
			XmlDocument xmld = new XmlDocument();
			XmlNodeList xml_list;
			System.Xml.XmlAttributeCollection attributes;
            string Control = "";
            string Action = "";
            string Node = "";
            string EventInfo = "";
            int id = -1;
            string sid;

            try {
                xmld.LoadXml(xml);
            } catch {
                ErrorNotify("Error in XML: " + xml);
                return;
            }

            //NotifyAll(-1, xml);
			//return;
            if (xmld.HasChildNodes) {
				xml_list = xmld.ChildNodes;
				foreach (XmlNode isy_event in xml_list) {
					// Right now all I see here is one child node called Event
                    //  attributes are seqnum and sid
                    //  children of this are: control, action, node, eventinfo
                    //    control will determine what type of event?
					//NotifyAll(-1, "Processing event");
                    attributes = isy_event.Attributes;
					foreach (XmlAttribute attr in attributes) {
						if ((attr.Name == "sid")) {
							sid = attr.Value;
						} else if (attr.Name == "seqnum") {
							id = int.Parse(attr.Value);
						} else {
						}
					}

                    // Maybe create a new isyEvent object and just fill it in.....
                    foreach (XmlNode evt_info in isy_event.ChildNodes) {
						if (evt_info.Name == "control") {
							// this determines the type of event. Will it
							// always come first?
							Control = evt_info.InnerText;
						} else if (evt_info.Name == "action") {
							Action = evt_info.InnerText;
						} else if (evt_info.Name == "node") {
							Node = evt_info.InnerText;
						} else if (evt_info.Name == "eventInfo") {
							//EventInfo = evt_info.InnerText;
                            EventInfo = evt_info.InnerXml;
						} else {
							// Unknown event data
						}
					}

                    //  Event Types
                    //    _0 = heartbeat
                    //    _1 = trigger
                    //    _2 = Protocol Specific Event
                    //    _3 = Nodes Updated Event
                    //    _4 = System Config Updated Event
                    //    _5 = System Status Event
                    //    _6 = Interner Access Event
                    //    _7 = System Progress Event
                    //    _8 = Security System Event
					//    _9 = System Alert Event
					//   _10 = Open ADR Event (electricity)
					//   _11 = Climate Event
                    //  Control types
                    //    ST - node status (status in action field
                    // 
                    // Who is going to interpet this data and do something 
                    // with it?

                    // Ignore the heartbeat for now. We could use this to set
					// a timeframe for getting the next one and if do
					// something to reset/halt if it doesn't come.

					switch (Control) {
						case "_0":
							NotifyAll(id, "Heartbeat", Action, Node, EventInfo);
							break;
						case "_1":
							switch (Action) {
								case "0":
									NotifyAll(id, "Trigger", "Program", Node, EventInfo);
									break;
								case "1":
									NotifyAll(id, "Trigger", "Program", Node, EventInfo);
									break;
								case "2":
									NotifyAll(id, "Trigger", "Program", Node, EventInfo);
									break;
								case "3":
									// Button press EventInfo -> "[address] command value"
									NotifyAll(id, "Trigger", "Button Press", Node, EventInfo);
									break;
								default:
									break;
							}
							break;
						case "_2":
							NotifyAll(id, "Protocol", Action, Node, EventInfo);
							break;
						case "_3":
							NotifyAll(id, "Nodes Update", Action, Node, EventInfo);
							break;
						case "_4":
							NotifyAll(id, "System Config", Action, Node, EventInfo);
							break;
						case "_5":
							switch (Action) {
								case "1":
									// busy
									NotifyAll(id, "System Status", "Busy", Node, EventInfo);
									break;
								default:
									// idle
									NotifyAll(id, "System Status", "Idle", Node, EventInfo);
									break;
							}
							break;
						case "_6":
							NotifyAll(id, "Internet", Action, Node, EventInfo);
							break;
						case "_7":
							NotifyAll(id, "Progress", Action, Node, EventInfo);
							break;
						case "_8":
							NotifyAll(id, "Security", Action, Node, EventInfo);
							break;
						case "_9":
							NotifyAll(id, "Alert", Action, Node, EventInfo);
							break;
						case "_10":
							NotifyAll(id, "Electricity", Action, Node, EventInfo);
							break;
						case "_11":
							NotifyAll(id, "Climate", Action, Node, EventInfo);
							break;
						case "ST":
							NotifyAll(id, "", Action, nodeName(Node), "");
							break;
						default:
							NotifyAll(id, Control, Action, Node, EventInfo);
							break;
					}
					//NotifyAll(-1, "Done Processing event");
                }
				//NotifyAll(-1, "Done Processing XML");
				Thread.Sleep(200);
            }
		}

		//
		// Parse the EventInfo string from a button trigger event into
		// human readable text.
		//
		private void ParseButtonTrigger(string EventInfo) {
			//   EventInfo -> "[address] command value"
			int i = EventInfo.IndexOf("]");
			if (i > 2) {
				string address = EventInfo.Substring(1, (i - 1));
				string name = nodeName(address.Trim());
				string cmdvalue = EventInfo.Substring(i + 1).Trim();
				int j = cmdvalue.IndexOf(" ");
				string cmd = cmdvalue.Substring(-1, j);
				string value = cmdvalue.Substring(j).Trim();

				// This is an attempt to output something that is more readable
				// it is not really an error!
				if (EventInfo.Contains("DON")) {
					ErrorNotify(name.PadRight(35, '.') + " sent ON " + value);
				} else if (EventInfo.Contains("DFON")) {
					ErrorNotify(name.PadRight(35, '.') + " sent FAST ON " + value);
				} else if (EventInfo.Contains("DOF")) {
					ErrorNotify(name.PadRight(35, '.') + " sent OFF " + value);
				} else if (EventInfo.Contains("DFOF")) {
					ErrorNotify(name.PadRight(35, '.') + " sent FAST OFF " + value);
				} else if (EventInfo.Contains("ST")) {
					ErrorNotify(name.PadRight(35, '.') + " sent STATUS " + value);
				} else if (EventInfo.Contains("BMAN")) {
					ErrorNotify(name.PadRight(35, '.') + " sent BMAN " + value);
				} else if (EventInfo.Contains("SMAN")) {
					ErrorNotify(name.PadRight(35, '.') + " sent SMAN " + value);
				} else {
					ErrorNotify(name.PadRight(35, '.') + " sent " + EventInfo);
				}
			}
		}

        //
        // Find the node name of an address
        //
        static string nodeName(string address) {

            foreach (node unode in isy_node) {
                if (unode.Address == address) {
                    return unode.Name;
                }
            }

            return ("?" + address + "?");
        }



		//
		// Directly call and process the ISY node list
		// 
		private void GetNodesConfig(string ip_address, string auth) {
			string reqxml;
			string node_xml = "";
			XmlDocument xmld;
			node new_node;
			XmlNodeList nodelist;
			XmlNode body;
			XmlNode nodes;
			XmlNode envelope;
			XmlNodeList details;
			HttpWebRequest request;
			StreamWriter writer;
			HttpWebResponse response;
			StreamReader reader;

			reqxml = "<?xml version=\'1.0\' encoding=\'utf-8\'?>";
			reqxml += "<s:Envelope><s:Body><u:GetNodesConfig";
			reqxml += " xmlns:u=\'urn:udi-com:service:X_Insteon_Lighting_Service:1\'>";
			reqxml += "</u:GetNodesConfig></s:Body></s:Envelope>" + ('\r' + '\n');

			request = (HttpWebRequest)HttpWebRequest.Create("http://" +
					ip_address + "/services");
			request.KeepAlive = false;
			request.Method = "POST";
			request.ContentType = "text/xml; charset=utf-8";
			request.Headers.Add("Authorization", auth);
			request.Headers.Add("SOAPAction", ("urn:udi-com:device:X_Insteon_Lighting_Service:1#UDIService"));
            writer = new StreamWriter(request.GetRequestStream());
			writer.Write(reqxml);
			writer.Flush();
			writer.Close();

			try {
				response = (HttpWebResponse)request.GetResponse();
				if ((response.ContentLength > 0)) {
					reader = new StreamReader(response.GetResponseStream());
					node_xml = reader.ReadToEnd();
					reader.Close();
				}
				response.Close();
			} catch (WebException wex) {
				ErrorNotify("HTTP request failed: " + wex.Message);
				return;
			}

			if ((node_xml == "")) {
				ErrorNotify("GetNodes: Failed to retrieve XML");
				return;
			}

			//  Clear the nodelist so we don't end up with duplicate nodes
			isy_node.Clear();

			// Create the XML Document and load the XML file
			xmld = new XmlDocument();
			xmld.LoadXml(node_xml);

			envelope = xmld.ChildNodes[1];
			body = envelope.ChildNodes[0];
			nodes = body.ChildNodes[0];
			nodelist = nodes.ChildNodes;

			foreach (XmlNode xnode in nodelist) {
				if ((xnode.Name == "node")) {
					details = xnode.ChildNodes;
					new_node = new node();
					new_node.Flag = xnode.Attributes[0].Value;
					foreach (XmlNode n in details) {
						if ((n.Name == "address")) {
							new_node.Address = n.InnerText;
						} else if ((n.Name == "name")) {
							new_node.Name = n.InnerText;
						} else if ((n.Name == "type")) {
							new_node.Type = n.InnerText;
						} else if ((n.Name.ToLower() == "elk_id")) {
							new_node.ElkID = n.InnerText;
						} else {
						}
					}

					isy_node.Add(new_node);

				} else if ((xnode.Name == "group")) {
					details = xnode.ChildNodes;
					new_node = new node();
					new_node.Flag = xnode.Attributes[0].Value;
					foreach (XmlNode n in details) {
						if ((n.Name == "address")) {
							new_node.Address = n.InnerText;
						} else if ((n.Name == "name")) {
							new_node.Name = n.InnerText;
						} else if ((n.Name == "deviceGroup")) {
							new_node.Group = n.InnerText;
						} else if ((n.Name.ToLower() == "elk_id")) {
							new_node.ElkID = n.InnerText;
						} else if ((n.Name == "link")) {
						} else {
						}
					}
					isy_node.Add(new_node);
				}
			}
		}

        //
        // Set the logging level of the ISY
        //
        private void SetDebugging(string ip_address, string auth) {
            string reqxml;
            HttpWebRequest request;
            StreamWriter writer;
            HttpWebResponse response;

            reqxml = "<?xml version=\'1.0\' encoding=\'utf-8\'?>";
            reqxml += "<s:Envelope><s:Body><u:SetDebugLevel";
            reqxml += " xmlns:u=\'urn:udi-com:service:X_Insteon_Lighting_Service:1\'>";
            reqxml += "<option>1</option>";
            reqxml += "</u:SetDebugLevel></s:Body></s:Envelope>" + ('\r' + '\n');

            request = (HttpWebRequest)HttpWebRequest.Create("http://" +
                    ip_address + "/services");
            request.KeepAlive = false;
            request.Method = "POST";
            request.ContentType = "text/xml; charset=utf-8";
            request.Headers.Add("Authorization", auth);
            request.Headers.Add("SOAPAction", ("urn:udi-com:device:X_Insteon_Lighting_Service:1#UDIService"));
            writer = new StreamWriter(request.GetRequestStream());
            writer.Write(reqxml);
            writer.Flush();
            writer.Close();

            try {
                response = (HttpWebResponse)request.GetResponse();
                response.Close();
            } catch (WebException wex) {
                ErrorNotify("HTTP request failed: " + wex.Message);
                return;
            }
       
        }

		protected void NotifyAll(int seq, string control, string action, string node, string text) {
			if (SendMessage != null) {
				SendMessage(this, new ISYEventMessage(seq.ToString(), control, action, node, text));
			}
		}


		//
		// this is for error messages, should we do something different with them, like
		// maybe pop up an error dialog?
		//
		protected void ErrorNotify(string text) {
			if (SendMessage != null) {
				SendMessage(this, new ISYEventMessage("", "", "", "", text));
			}
		}
	}
}
