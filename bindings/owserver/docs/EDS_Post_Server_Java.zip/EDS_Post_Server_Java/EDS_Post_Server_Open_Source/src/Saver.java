/*
Copyright 2012 Embedded Data Systems, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

import java.util.concurrent.LinkedBlockingQueue;
import org.w3c.dom.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.parsers.*;
import org.xml.sax.InputSource;


public class Saver extends Thread {
	private LinkedBlockingQueue<String> rxQueue;
	private String FileName;

	Saver(LinkedBlockingQueue<String> bq, String fn) {
		this.rxQueue = bq;
		this.FileName = fn;
	}

	// Received XML data is placed in the rxQueue. Here we take data from the queue, parse and
	// save it.
	@Override
	public void run() {
		try {
			while(true) {
				//
				String XMLData = rxQueue.take().toString();
//				System.out.println(XMLData);
				if(FileName != null) {
					String CSVData = ParseData(XMLData);
					if(CSVData != null) {
						SaveData(CSVData);
					}
				}
			}
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}
	}
	
	private String ParseData(String XMLData) {
		String outputStr = "";
		Document doc;
		NodeList nodes;
		Element name;

		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();

			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(XMLData));

			doc = db.parse(is);
			XMLParsingHelpers XMLHelpers = new XMLParsingHelpers();

			String t = XMLHelpers.xmlDocumentToString(doc);

			// Loop through the child nodes
			NodeList nl = doc.getDocumentElement().getChildNodes();
			for(int x=0; x < nl.getLength(); x++) {
				Node node = nl.item(x);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					String str = node.getNodeName();
					int index = str.indexOf("owd_");
					if(index != 0) {
						continue;
					}

					if(node.hasChildNodes()) {
						Element element = (Element)node;

						nodes = element.getElementsByTagName("EUI");
						name = (Element) nodes.item(0);
						if(name == null) {
							nodes = element.getElementsByTagName("ROMId");
							name = (Element) nodes.item(0);
						}
						if(name != null) {
							outputStr += XMLHelpers.getCharacterDataFromElement(name);
						}

						nodes = element.getElementsByTagName("TimeStamp");
						name = (Element) nodes.item(0);
						if(name != null) {
							outputStr += "," + XMLHelpers.getCharacterDataFromElement(name);
						}
						else {
							Date now = new Date();
							SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm.ss");
							outputStr += "," + formatter.format(now);
						}

						nodes = element.getElementsByTagName("Temperature");
						name = (Element) nodes.item(0);
						if(name != null) {
							outputStr += "," + XMLHelpers.getCharacterDataFromElement(name);
						}

						nodes = element.getElementsByTagName("Humidity");
						name = (Element) nodes.item(0);
						if(name != null) {
							outputStr += "," + XMLHelpers.getCharacterDataFromElement(name);
						}

						outputStr += "\n";
					}
				}
			}
//			outputStr += XMLData;
			return outputStr;
		}
		catch(Exception e) {
			System.out.println(e.toString());
			return null;
		}
	}

	private void SaveData(String Data) {
		String output;
		try {
			FileWriter fstream = new FileWriter(FileName, true);
			BufferedWriter out = new BufferedWriter(fstream);
			out.write(Data);
			out.close();
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
	}

}
