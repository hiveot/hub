/*
Copyright 2012 Embedded Data Systems, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.concurrent.LinkedBlockingQueue;


public class Receiver extends Thread {
	private Socket cSocket;
	private LinkedBlockingQueue<String> rxQueue;

	Receiver(Socket skt, LinkedBlockingQueue<String> bq) {
		this.cSocket = skt;
		this.rxQueue = bq;
	}

	@Override
	public void run() {
		try {
			String cLine;
			String boundary = "";
			String rxXML = "";
			int bOffset;
			int rxState = 0;

			// Get data from OW Server or MN Controller, isolate XML and send it to parser
			BufferedReader rxData = new BufferedReader(new InputStreamReader(cSocket.getInputStream()));
			while((rxState != 4) && ((cLine = rxData.readLine()) != null)) {
				switch(rxState) {
					case 0:	// Find boundary string
						bOffset = cLine.indexOf("boundary");
						if(bOffset != -1) {
							boundary = cLine.substring(bOffset+9);
							rxState = 1;
						}
						break;

					case 1:	// Find beginning boundary marker
						bOffset = cLine.indexOf(boundary);
						if(bOffset != -1) {
							rxState = 2;
						}
						break;

					case 2:	// Remove baggage after boundary marker
						bOffset = cLine.indexOf("<?xml");
						if(bOffset != -1) {
							rxXML = cLine.toString() + "\n";
							rxState = 3;
						}
						break;

					case 3:	// Save XML data until next boundary marker, close socket when done
						bOffset = cLine.indexOf(boundary);
						if(bOffset == -1) {
							rxXML += cLine.toString() + "\n";
						}
						else {
							// Close socket
							rxState = 4;
							rxQueue.put(rxXML);
						}
						break;

					case 4: // Do nothing
						break;
				}

//				System.out.println(cLine);
			}
			return;
		}

		catch(Exception e) {

		}
	}
}
