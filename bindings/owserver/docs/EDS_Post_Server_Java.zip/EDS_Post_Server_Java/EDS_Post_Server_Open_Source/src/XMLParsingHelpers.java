/*
Copyright 2012 Embedded Data Systems, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

import java.io.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

/**
 * Collection of methods that assist in managing XML files
 *
 * @author Larry Wood
 */
public class XMLParsingHelpers {

	/**
	 * Returns a string that is the content of the element passed to it
	 *
	 * @param e		the element to retrieve the data from
	 *
	 * @return		a string containing the content of the element, or <code>null</code> if the content could not be found
	 *
	 */
	public String getCharacterDataFromElement(Element e) {
	    Node child = e.getFirstChild();
	    if (child instanceof CharacterData) {
			CharacterData cd = (CharacterData) child;
			return cd.getData();
	    }
	    return null;
	}

	/**
	 * Returns the child elements for a specific EUI or ROMId.
	 * <p>
	 * The XML file from a OW Server or MeshNet controller may contain multiple devices. The order
	 * these devices appear in the XML file is not fixed, it may change.
	 * Because of this devices should be accessed according to their EUI (or ROMId), and not based on
	 * their order in the XML file.
	 * <p>
	 * This method looks for either the 'EUI' tag or the 'ROMId' tag when searching.
	 *
	 * @param EUI		the EUI or ROMId identifying the child elements to isolate
	 * @param XMLFile	XML file to search
	 *
	 * @return			a NodeList for the device containing the EUI (or ROMId), or <code>null</code> if the EUI could not be found
	 *
	 */
	public Document getNodeListByEUI(String EUI, Document XMLFile) {
		try {
			NodeList nl = XMLFile.getDocumentElement().getChildNodes();
			for(int x=0; x < nl.getLength(); x++) {
				Node node = nl.item(x);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					String str = node.getNodeName();
					int index = str.indexOf("owd_");
					if(index != 0) {
						continue;
					}

//					System.out.println("Name: " + node.getNodeName());
//					System.out.println("Child Nodes: " + node.hasChildNodes());

					if(node.hasChildNodes()) {
						Element Description = (Element) node;
						String Desc = Description.getAttribute("Description");
						NodeList nlc = node.getChildNodes();
//						System.out.println("Child Node Length: " + nlc.getLength());

						for (int y = 0; y  < nlc.getLength(); y ++) {
							if (node.getNodeType() == Node.ELEMENT_NODE) {
								Node nc = nlc.item(y);
								if((nc.getNodeName().equals("EUI") && getCharacterDataFromElement((Element) nc).equals(EUI)) ||
									(nc.getNodeName().equals("ROMId") && getCharacterDataFromElement((Element) nc).equals(EUI))) {
									Document ndb = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
									Element root = ndb.createElement("root");
									ndb.appendChild(root);
									Text text = ndb.createTextNode(Desc);
									Element DescChild = ndb.createElement("Description");
									root.appendChild(DescChild);
									DescChild.appendChild(text);
									for (int i = 0; i < nlc.getLength(); i++) {
										Node el = nlc.item(i);
										Node copyNode = ndb.importNode(el, true);
										root.appendChild(ndb.importNode(copyNode, true));
									}
									return ndb;

								}
							}
						}
					}
				}
			}
			return null;
		}
		catch (Exception e) {
//			e.printStackTrace();
			return null;
		}
		finally {
		}
	}

	/**
	 * Converts a Document to a string.
	 * Used for diagnostic purposes
	 *
	 * @param doc	Document to convert
	 *
	 * @return		a String of the document
	 *
	 */
	public String xmlDocumentToString(Document doc) {
		try {
			// Set up a transformer
			TransformerFactory transfac = TransformerFactory.newInstance();
			Transformer trans = transfac.newTransformer();
			trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			trans.setOutputProperty(OutputKeys.INDENT, "yes");

			// Create string from xml tree
			StringWriter sw = new StringWriter();
			StreamResult result = new StreamResult(sw);
			DOMSource source = new DOMSource(doc);
			trans.transform(source, result);
			String xmlString = sw.toString();

			return xmlString.toString();
		}
		catch (Exception e)
		{
			return "ERROR";
		}
	}



}
