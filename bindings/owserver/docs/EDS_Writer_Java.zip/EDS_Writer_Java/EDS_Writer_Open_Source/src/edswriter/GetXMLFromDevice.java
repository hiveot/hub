/*
Copyright 2012 Embedded Data Systems, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package edswriter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Method that retrieves a XML file from a server using HTTP
 *
 * @author Larry Wood
 */
public class GetXMLFromDevice {

	/**
	* Returns the output from a server and returns it as a string.
	*
	* @param serverUrl	URL of the server to access
	*
	* @return			data from server, or an error message if there was an error
	* 
	*/
	public String GetDataUsingHTTP(String serverUrl)
	{
	    URL url = null;
	    BufferedReader reader = null;
	    StringBuilder stringBuilder;

	    try {
			// Create the HttpURLConnection
			url = new URL(serverUrl);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();

			// Use HTTP GET
			connection.setRequestMethod("GET");

			// Give it 4 seconds to respond
			connection.setReadTimeout(4*1000);
			connection.setConnectTimeout(4*1000);
			connection.connect();

			// Read the output from the server
			reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			stringBuilder = new StringBuilder();

			String line = null;
			while ((line = reader.readLine()) != null)
			{
				stringBuilder.append(line + "\n");
			}
			return stringBuilder.toString();
		}
		catch (Exception e) {
			return e.getMessage();
		}
		finally
		{
			// Close the reader; this can throw an exception too, so
			// wrap it in another try/catch block.
			if (reader != null) {
				try {
					reader.close();
				}
				catch (IOException ioe) {
					return ioe.getMessage();
				}
			}
	    }
	}

}
