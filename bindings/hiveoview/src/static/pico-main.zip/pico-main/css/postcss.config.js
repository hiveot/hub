module.exports = {
  map: false,
  plugins: {
    autoprefixer: {
      cascade: false
    }
  }
}